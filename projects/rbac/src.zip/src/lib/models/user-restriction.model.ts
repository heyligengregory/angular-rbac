export type UserRestriction = {
  name: string;
  value: string;
}
