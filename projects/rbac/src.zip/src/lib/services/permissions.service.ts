import { Inject, Injectable } from '@angular/core';
import { UserRole } from '../models/user-role.model';
import { Observable, tap } from 'rxjs';
import { ROLE_ACCESS_PROVIDER } from '../constants/constants';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PermissionsService {
  private _roles: UserRole[] = [];

  constructor(
    private httpClient: HttpClient,
    @Inject(ROLE_ACCESS_PROVIDER)
    private roleAccessProvider: (Observable<UserRole[]>) | string | null
  ) {}

  load(): Observable<UserRole[]> {
    if (!this.roleAccessProvider) {
      throw new Error(
        'Role Access provider is not configured. Please provide it using AdamoRoleAccessPoliciesModule.forRoot.'
      );
    }

    if (typeof this.roleAccessProvider === 'string') {
      return this.httpClient
        .get<UserRole[]>(this.roleAccessProvider)
        .pipe(tap((response) => this.initRoles(response)));
    }

    return this.roleAccessProvider.pipe(
      tap((response) => this.initRoles(response))
    );
  }

  hasRole(roleName: string): boolean {
    return this._roles.some((role) => role.roleName === roleName);
  }

  hasPermission(permission: string): boolean {
    return this._roles.some((role) => role.permissions.includes(permission));
  }

  hasRestriction(restrictionName: string, restrictionValue: string): boolean {
    return this._roles.some((role) =>
      role.restrictions.some(
        (restriction) =>
          restriction.name === restrictionName &&
          restriction.value === restrictionValue
      )
    );
  }

  private initRoles(responseRoles: any) {
    let roles = responseRoles;
    if (typeof roles === 'string') {
      roles = JSON.parse(roles);
    }

    this._roles = roles;
  }
}
