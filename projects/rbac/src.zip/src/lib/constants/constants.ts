import { InjectionToken } from "@angular/core";

export const ROLE_ACCESS_PROVIDER = "ROLE_ACCESS_PROVIDER";
export const UNAUTHORIZED_ROUTE = new InjectionToken<string>("UnauthorizedRoute");