import { CommonModule } from '@angular/common';
import { NgModule, Provider, ModuleWithProviders } from '@angular/core';

import { HasRestrictionDirective } from './lib/directives/has-restriction.directive';
import { HasPermissionDirective } from './lib/directives/has-permission.directive';
import { PermissionsService } from './lib/services/permissions.service';
import { ROLE_ACCESS_PROVIDER, UNAUTHORIZED_ROUTE } from './lib/constants/constants';

/*
 * Public API Surface of adamo-role-access-policies
 */

export { ROLE_ACCESS_PROVIDER, UNAUTHORIZED_ROUTE } from './lib/constants/constants';
export * from './lib/models/user-role.model';
export * from './lib/models/user-restriction.model';
export * from './lib/guards/authorization.guard';
export * from './lib/directives/has-permission.directive';
export * from './lib/directives/has-restriction.directive';
export * from './lib/services/permissions.service';

export interface AdamoRoleAccessPoliciesConfig {
    roleAccessSource?: Provider;
    unauthorizedRoute: string;
}

@NgModule({
    imports: [CommonModule],
    declarations: [HasPermissionDirective, HasRestrictionDirective],
    exports: [HasPermissionDirective, HasRestrictionDirective],
})
export class AdamoRoleAccessPoliciesModule {
    static forRoot(config: AdamoRoleAccessPoliciesConfig): ModuleWithProviders<AdamoRoleAccessPoliciesModule> {
        return {
            ngModule: AdamoRoleAccessPoliciesModule,
            providers: [
                PermissionsService,
                config.roleAccessSource || { provide: ROLE_ACCESS_PROVIDER, useFactory: () => {
                    throw new Error('Invalid roleAccessSource configuration.');
                }},
                {
                    provide: UNAUTHORIZED_ROUTE,
                    useValue: config.unauthorizedRoute || '/unauthorized',
                },
            ]
        }
    }
}